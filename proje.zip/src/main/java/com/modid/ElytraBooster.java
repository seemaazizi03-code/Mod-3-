package com.modid;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.projectile.FireworkRocketEntity;
import net.minecraft.util.math.Vec3d;

/** Elytra uçarken fişek basınca ekstra hız. Boost 1 = vanilla, 10 = çok hızlı. */
public class ElytraBooster extends Module {
    public final Setting.Num boost = add(new Setting.Num("Boost", 2, 1, 10, 0.1));

    public ElytraBooster() {
        super("Elytra Booster", "Combat");
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || !p.isFallFlying()) return;
        double b = boost.get();
        if (b <= 1.0) return;

        boolean boosting = !mc.world.getEntitiesByClass(FireworkRocketEntity.class,
                p.getBoundingBox().expand(2.0), e -> true).isEmpty();
        if (!boosting) return;

        // Vanilla fişek formülü, hedef hız 1.5 yerine 1.5 * boost
        Vec3d rot = p.getRotationVec(1f);
        Vec3d v = p.getVelocity();
        Vec3d goal = rot.multiply(1.5 * b);
        p.setVelocity(v.add(rot.multiply(0.1)).add(goal.subtract(v).multiply(0.5)));
    }
}
