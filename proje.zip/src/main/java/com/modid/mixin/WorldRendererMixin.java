package com.modid.mixin;

import com.modid.NoRender;
import net.minecraft.client.render.WorldRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WorldRenderer.class)
public abstract class WorldRendererMixin {

    @Inject(method = "renderWeather", at = @At("HEAD"), cancellable = true, require = 0)
    private void modid$weather(CallbackInfo ci) {
        if (NoRender.on(NoRender.I.weather)) ci.cancel();
    }

    @Inject(method = "tickRainSplashing", at = @At("HEAD"), cancellable = true, require = 0)
    private void modid$splash(CallbackInfo ci) {
        if (NoRender.on(NoRender.I.weather)) ci.cancel();
    }
}
