package com.modid.mixin;

import com.modid.FreeLook;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow
    protected abstract void setRotation(float yaw, float pitch);

    /** Kamera açısını FreeLook değerleriyle değiştir (F5 dahil). */
    @Inject(method = "update",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;setRotation(FF)V", shift = At.Shift.AFTER),
            require = 0)
    private void modid$free(BlockView area, Entity focused, boolean thirdPerson, boolean inverse,
                            float tickDelta, CallbackInfo ci) {
        if (!FreeLook.active) return;
        setRotation(inverse ? FreeLook.yaw + 180f : FreeLook.yaw, inverse ? -FreeLook.pitch : FreeLook.pitch);
    }
}
