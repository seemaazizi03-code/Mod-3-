package com.modid.mixin;

import com.modid.NoRender;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.entity.Entity;
import net.minecraft.particle.ParticleEffect;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ParticleManager.class)
public abstract class ParticleManagerMixin {

    @Inject(method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void modid$add(ParticleEffect effect, double x, double y, double z, double vx, double vy, double vz,
                           CallbackInfoReturnable<Particle> cir) {
        if (NoRender.blocked(effect)) cir.setReturnValue(null);
    }

    @Inject(method = "addEmitter(Lnet/minecraft/entity/Entity;Lnet/minecraft/particle/ParticleEffect;)V",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void modid$emit(Entity entity, ParticleEffect effect, CallbackInfo ci) {
        if (NoRender.blocked(effect)) ci.cancel();
    }

    @Inject(method = "addEmitter(Lnet/minecraft/entity/Entity;Lnet/minecraft/particle/ParticleEffect;I)V",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void modid$emit2(Entity entity, ParticleEffect effect, int maxAge, CallbackInfo ci) {
        if (NoRender.blocked(effect)) ci.cancel();
    }
}
