package com.modid.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import com.modid.NoRender;
import net.minecraft.client.render.BackgroundRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BackgroundRenderer.class)
public abstract class BackgroundRendererMixin {

    /** Körlük / karanlık (darkness) sisi. */
    @SuppressWarnings({"rawtypes", "unchecked"})
    @Inject(method = "getFogModifier", at = @At("HEAD"), cancellable = true, require = 0)
    private static void modid$blind(CallbackInfoReturnable cir) {
        if (NoRender.on(NoRender.I.blindness)) cir.setReturnValue(null);
    }

    /** Tüm sis: Nether, görüş mesafesi, su altı. */
    @Inject(method = "applyFog", at = @At("RETURN"), require = 0)
    private static void modid$fog(CallbackInfo ci) {
        if (NoRender.on(NoRender.I.fog)) {
            RenderSystem.setShaderFogStart(1.0E8f);
            RenderSystem.setShaderFogEnd(1.0E8f + 1000f);
        }
    }
}
