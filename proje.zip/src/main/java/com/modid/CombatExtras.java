package com.modid;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/**
 * Yeni Combat modülleri. Mevcut AttackAura / AutoClicker'a dokunmaz.
 * ModIDClient.onInitializeClient() içinde Modules.init()'ten SONRA CombatExtras.register() çağır.
 */
public final class CombatExtras {
    private CombatExtras() {}

    public static final AntiBot ANTI_BOT = new AntiBot();
    public static final AutoTotem AUTO_TOTEM = new AutoTotem();
    public static final AutoTrap AUTO_TRAP = new AutoTrap();
    public static final HitBoxes HIT_BOXES = new HitBoxes();
    public static final TargetStrafe TARGET_STRAFE = new TargetStrafe();
    public static final TriggerBot TRIGGER_BOT = new TriggerBot();

    public static void register() {
        Modules.ALL.add(ANTI_BOT);
        Modules.ALL.add(AUTO_TOTEM);
        Modules.ALL.add(AUTO_TRAP);
        Modules.ALL.add(HIT_BOXES);
        Modules.ALL.add(TARGET_STRAFE);
        Modules.ALL.add(TRIGGER_BOT);
    }

    // ---------------------------------------------------------------- yardımcılar

    static boolean matches(String mode, LivingEntity e) {
        return switch (mode) {
            case "Mobs" -> e instanceof HostileEntity;
            case "Players" -> e instanceof PlayerEntity;
            default -> true;
        };
    }

    static LivingEntity nearest(MinecraftClient mc, double range, String mode) {
        if (mc.player == null || mc.world == null) return null;
        LivingEntity best = null;
        double bestD = range * range;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == mc.player || e instanceof ArmorStandEntity) continue;
            if (!le.isAlive() || AntiBot.isBot(le) || !matches(mode, le)) continue;
            double d = mc.player.squaredDistanceTo(le);
            if (d < bestD) { bestD = d; best = le; }
        }
        return best;
    }

    static void attack(MinecraftClient mc, Entity target) {
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    // ---------------------------------------------------------------- AntiBot

    public static class AntiBot extends Module {
        final Setting.Bool tab = add(new Setting.Bool("Tab list check", true));
        final Setting.Bool invis = add(new Setting.Bool("Invisible check", true));
        final Setting.Num age = add(new Setting.Num("Min age (ticks)", 20, 0, 100, 1));

        public AntiBot() { super("Anti Bot", "Combat"); }

        /** Diğer modüller hedef seçerken bunu çağırır. */
        public static boolean isBot(Entity e) {
            AntiBot m = ANTI_BOT;
            if (!m.isEnabled() || !(e instanceof PlayerEntity p)) return false;
            MinecraftClient mc = MinecraftClient.getInstance();
            if (m.tab.get() && mc.getNetworkHandler() != null
                    && mc.getNetworkHandler().getPlayerListEntry(p.getUuid()) == null) return true;
            return m.invis.get() && p.isInvisible() && p.age < m.age.get();
        }
    }

    // ---------------------------------------------------------------- AutoTotem

    public static class AutoTotem extends Module {
        final Setting.Num health = add(new Setting.Num("Health", 10, 1, 20, 1));
        final Setting.Bool onlyLow = add(new Setting.Bool("Only when low", false));
        final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 2, 0, 20, 1));
        private int wait;

        public AutoTotem() { super("Auto Totem", "Combat"); }

        @Override
        public void onTick(MinecraftClient mc) {
            ClientPlayerEntity p = mc.player;
            if (p == null || mc.interactionManager == null) return;
            if (p.currentScreenHandler != p.playerScreenHandler) return;
            if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
            if (onlyLow.get() && p.getHealth() + p.getAbsorptionAmount() > health.get()) return;
            if (wait-- > 0) return;
            for (int i = 0; i < 36; i++) {
                if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                    int slot = i < 9 ? 36 + i : i;
                    mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, p);
                    wait = (int) delay.get();
                    return;
                }
            }
        }
    }

    // ---------------------------------------------------------------- AutoTrap

    public static class AutoTrap extends Module {
        final Setting.Num range = add(new Setting.Num("Range", 4.5, 2, 6, 0.5));
        final Setting.Bool top = add(new Setting.Bool("Cover top", true));
        final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 1, 0, 10, 1));
        private int wait;

        public AutoTrap() { super("Auto Trap", "Combat"); }

        @Override
        public void onTick(MinecraftClient mc) {
            ClientPlayerEntity p = mc.player;
            if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
            if (wait-- > 0) return;

            int obby = -1;
            for (int i = 0; i < 9; i++)
                if (p.getInventory().getStack(i).isOf(Items.OBSIDIAN)) { obby = i; break; }
            if (obby < 0) return;

            LivingEntity t = nearest(mc, range.get(), "Players");
            if (t == null) return;

            BlockPos base = t.getBlockPos();
            List<BlockPos> plan = new ArrayList<>();
            for (Direction d : Direction.Type.HORIZONTAL) plan.add(base.offset(d));
            for (Direction d : Direction.Type.HORIZONTAL) plan.add(base.offset(d).up());
            if (top.get()) plan.add(base.up(2));

            for (BlockPos pos : plan) {
                if (!mc.world.getBlockState(pos).isReplaceable()) continue;
                if (p.getEyePos().squaredDistanceTo(Vec3d.ofCenter(pos)) > 4.5 * 4.5) continue;
                if (place(mc, pos, obby)) { wait = (int) delay.get(); return; }
            }
        }

        private boolean place(MinecraftClient mc, BlockPos pos, int slot) {
            for (Direction d : Direction.values()) {
                BlockPos n = pos.offset(d);
                if (mc.world.getBlockState(n).isReplaceable()) continue;
                Direction face = d.getOpposite();
                Vec3d hitVec = Vec3d.ofCenter(n).add(Vec3d.of(face.getVector()).multiply(0.5));
                int prev = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = slot;
                mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(hitVec, face, n, false));
                mc.player.swingHand(Hand.MAIN_HAND);
                mc.player.getInventory().selectedSlot = prev;
                return true;
            }
            return false;
        }
    }

    // ---------------------------------------------------------------- HitBoxes

    /** Asıl iş EntityHitboxMixin içinde; modül sadece ayarı tutar. */
    public static class HitBoxes extends Module {
        public final Setting.Num expand = add(new Setting.Num("Expand", 0.2, 0, 1, 0.05));
        public final Setting.Bool playersOnly = add(new Setting.Bool("Players only", true));

        public HitBoxes() { super("Hit Boxes", "Combat"); }
    }

    // ---------------------------------------------------------------- TargetStrafe

    public static class TargetStrafe extends Module {
        final Setting.Num radius = add(new Setting.Num("Radius", 2.5, 1, 6, 0.1));
        final Setting.Num speed = add(new Setting.Num("Speed", 0.24, 0.1, 0.6, 0.01));
        final Setting.Bool holdJump = add(new Setting.Bool("Only while jump held", true));
        final Setting.Mode target = add(new Setting.Mode("Target", new String[]{"Players", "Mobs", "All"}));
        private int dir = 1;

        public TargetStrafe() { super("Target Strafe", "Combat"); }

        @Override
        public void onTick(MinecraftClient mc) {
            ClientPlayerEntity p = mc.player;
            if (p == null || mc.currentScreen != null || p.isFallFlying()) return;
            if (holdJump.get() && !mc.options.jumpKey.isPressed()) return;
            LivingEntity t = nearest(mc, radius.get() + 4, target.get());
            if (t == null) return;

            if (p.horizontalCollision) dir = -dir;
            double r = radius.get();
            double ang = Math.atan2(p.getZ() - t.getZ(), p.getX() - t.getX()) + dir * (speed.get() / r);
            double wx = t.getX() + Math.cos(ang) * r - p.getX();
            double wz = t.getZ() + Math.sin(ang) * r - p.getZ();
            double len = Math.sqrt(wx * wx + wz * wz);
            if (len < 1.0E-4) return;
            double sp = speed.get();
            p.setVelocity(wx / len * sp, p.getVelocity().y, wz / len * sp);
        }
    }

    // ---------------------------------------------------------------- TriggerBot

    public static class TriggerBot extends Module {
        final Setting.Num minCooldown = add(new Setting.Num("Min cooldown", 0.9, 0, 1, 0.05));
        final Setting.Mode target = add(new Setting.Mode("Target", new String[]{"Players", "Mobs", "All"}));

        public TriggerBot() { super("Trigger Bot", "Combat"); }

        @Override
        public void onTick(MinecraftClient mc) {
            ClientPlayerEntity p = mc.player;
            if (p == null || mc.interactionManager == null || mc.currentScreen != null) return;
            HitResult h = mc.crosshairTarget;
            if (!(h instanceof EntityHitResult er) || !(er.getEntity() instanceof LivingEntity le)) return;
            if (!le.isAlive() || AntiBot.isBot(le) || !matches(target.get(), le)) return;
            if (p.getAttackCooldownProgress(0.5f) < minCooldown.get()) return;
            attack(mc, le);
        }
    }
}
