package com.modid;

import java.util.Locale;

public abstract class Setting {
    public final String name;

    protected Setting(String name) {
        this.name = name;
    }

    public static class Num extends Setting {
        public final double min, max, step;
        private double value;

        public Num(String name, double value, double min, double max, double step) {
            super(name);
            this.min = min;
            this.max = max;
            this.step = step;
            this.value = value;
        }

        public double get() { return value; }

        public void set(double v) { value = Math.max(min, Math.min(max, v)); }

        public String display() {
            if (step >= 1) return String.valueOf(Math.round(value));
            return String.format(Locale.ROOT, step >= 0.1 ? "%.1f" : "%.2f", value);
        }
    }

    public static class Bool extends Setting {
        private boolean value;

        public Bool(String name, boolean value) {
            super(name);
            this.value = value;
        }

        public boolean get() { return value; }

        public void toggle() { value = !value; }
    }

    public static class Mode extends Setting {
        private final String[] modes;
        private int index;

        public Mode(String name, String[] modes) {
            super(name);
            this.modes = modes;
        }

        public String get() { return modes[index]; }

        public void next() { index = (index + 1) % modes.length; }
    }
}
