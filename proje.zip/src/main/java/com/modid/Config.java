package com.modid;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.Properties;

/** Ayarları ve HUD konumlarını .minecraft/config/wexaclient.properties dosyasına kaydeder. */
public final class Config {
    private Config() {}

    private static boolean loaded;

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("wexaclient.properties");
    }

    public static void load() {
        Properties pr = new Properties();
        Path f = file();
        if (Files.exists(f)) {
            try (InputStream in = Files.newInputStream(f)) {
                pr.load(in);
            } catch (IOException ignored) {
            }
        }
        for (Module m : Modules.ALL) {
            for (Object o : m.settings) {
                Setting s = (Setting) o;
                apply(s, pr.getProperty(m.name + "." + s.name));
            }
            String en = pr.getProperty(m.name + ".__enabled");
            if (en != null) {
                boolean want = Boolean.parseBoolean(en);
                if (want != m.isEnabled()) {
                    try {
                        m.setEnabled(want);
                    } catch (Throwable ignored) {
                    }
                }
            }
        }
        for (String k : pr.stringPropertyNames()) {
            if (k.startsWith("hud.") && k.endsWith(".x")) {
                String id = k.substring(4, k.length() - 2);
                try {
                    int x = Integer.parseInt(pr.getProperty(k));
                    int y = Integer.parseInt(pr.getProperty("hud." + id + ".y", "0"));
                    HudPos.set(id, x, y);
                } catch (NumberFormatException ignored) {
                }
            }
        }
        loaded = true;
        Runtime.getRuntime().addShutdownHook(new Thread(Config::save));
    }

    public static synchronized void save() {
        if (!loaded) return;
        Properties pr = new Properties();
        for (Module m : Modules.ALL) {
            pr.setProperty(m.name + ".__enabled", String.valueOf(m.isEnabled()));
            for (Object o : m.settings) {
                Setting s = (Setting) o;
                String v = value(s);
                if (v != null) pr.setProperty(m.name + "." + s.name, v);
            }
        }
        for (Map.Entry<String, int[]> e : HudPos.all().entrySet()) {
            pr.setProperty("hud." + e.getKey() + ".x", String.valueOf(e.getValue()[0]));
            pr.setProperty("hud." + e.getKey() + ".y", String.valueOf(e.getValue()[1]));
        }
        try {
            Path f = file();
            Files.createDirectories(f.getParent());
            try (OutputStream out = Files.newOutputStream(f)) {
                pr.store(out, "WexaClient");
            }
        } catch (IOException ignored) {
        }
    }

    private static String value(Setting s) {
        if (s instanceof Setting.Bool b) return String.valueOf(b.get());
        if (s instanceof Setting.Num n) return String.valueOf(n.get());
        if (s instanceof Setting.Mode m) return m.get();
        return null;
    }

    private static void apply(Setting s, String v) {
        if (v == null) return;
        try {
            if (s instanceof Setting.Bool b) {
                boolean want = Boolean.parseBoolean(v);
                if (b.get() != want) b.toggle();
            } else if (s instanceof Setting.Num n) {
                n.set(Double.parseDouble(v));
            } else if (s instanceof Setting.Mode m) {
                String start = m.get();
                int guard = 0;
                do {
                    if (m.get().equals(v)) return;
                    m.next();
                } while (!m.get().equals(start) && ++guard < 64);
            }
        } catch (Throwable ignored) {
        }
    }
}
