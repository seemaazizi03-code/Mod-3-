package com.modid;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

/** Hedef çevresinde dönen beyaz ESP'ler (esp1..esp5). Hepsi ekran üstüne çizilir. */
public final class Esp {
    private Esp() {}

    public static void draw(DrawContext ctx, MinecraftClient mc, LivingEntity t, String style) {
        float td = mc.getRenderTickCounter().getTickDelta(true);
        Vec3d base = t.getLerpedPos(td);
        double w = Math.max(0.4, t.getWidth()), h = t.getHeight();
        double time = (System.currentTimeMillis() % 100000L) / 1000.0;

        switch (style) {
            case "esp2" -> orbit(ctx, mc, base, w, h, time);
            case "esp3" -> scan(ctx, mc, base, w, h, time);
            case "esp4" -> square(ctx, mc, base.add(0, h * 0.5, 0), t, time);
            case "esp5" -> atom(ctx, mc, base.add(0, h * 0.5, 0), w, time);
            default -> ring(ctx, mc, base.add(0, 0.05, 0), w * 0.8 + 0.2, 48, time * 1.6, 255);
        }
    }

    // ---- esp1: ayakta dönen halka
    private static void ring(DrawContext c, MinecraftClient mc, Vec3d center, double r, int n, double spin, int maxA) {
        for (int i = 0; i < n; i++) {
            double a = Math.PI * 2 * i / n + spin;
            double bright = 0.35 + 0.65 * (0.5 + 0.5 * Math.cos(Math.PI * 2 * i / n));
            dot(c, mc, center.add(Math.cos(a) * r, 0, Math.sin(a) * r), (int) (maxA * bright), 2);
        }
    }

    // ---- esp2: vücut etrafında dönen 3 parlak nokta + kuyruk
    private static void orbit(DrawContext c, MinecraftClient mc, Vec3d base, double w, double h, double time) {
        double r = w * 0.8 + 0.2;
        for (int k = 0; k < 3; k++) {
            for (int j = 0; j < 12; j++) {
                double tt = time - j * 0.035;
                double a = tt * 2.6 + k * Math.PI * 2 / 3;
                double y = h * (0.55 + 0.32 * Math.sin(tt * 1.8 + k * 2.1));
                int alpha = (int) (255 * (1.0 - j / 12.0));
                dot(c, mc, base.add(Math.cos(a) * r, y, Math.sin(a) * r), alpha, j == 0 ? 4 : 2);
            }
        }
    }

    // ---- esp3: vücutta aşağı yukarı gezen halka
    private static void scan(DrawContext c, MinecraftClient mc, Vec3d base, double w, double h, double time) {
        double y = h * (0.5 + 0.5 * Math.sin(time * 1.7));
        ring(c, mc, base.add(0, y, 0), w * 0.75 + 0.15, 40, time * 2.0, 255);
        ring(c, mc, base.add(0, 0.05, 0), w * 0.75 + 0.15, 24, -time, 70);
    }

    // ---- esp4: ekranda dönen yuvarlak kare
    private static void square(DrawContext ctx, MinecraftClient mc, Vec3d pos, LivingEntity t, double time) {
        double[] s = project(mc, pos);
        if (s == null) return;
        int sh = mc.getWindow().getScaledHeight();
        double tan = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        double size = MathHelper.clamp((sh / 2.0) / tan * (t.getHeight() * 0.9) / s[2], 14.0, 90.0);
        int r = (int) (size / 2);
        float ang = (float) ((time % 2.4) / 2.4 * 360.0);

        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate(s[0], s[1], 0);
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(ang));
        int col = 0xFFFFFFFF, th = 2;
        ctx.fill(-r + 3, -r, r - 3, -r + th, col);
        ctx.fill(-r + 3, r - th, r - 3, r, col);
        ctx.fill(-r, -r + 3, -r + th, r - 3, col);
        ctx.fill(r - th, -r + 3, r, r - 3, col);
        ctx.fill(-r + 1, -r + 1, -r + 3, -r + 3, col);
        ctx.fill(r - 3, -r + 1, r - 1, -r + 3, col);
        ctx.fill(-r + 1, r - 3, -r + 3, r - 1, col);
        ctx.fill(r - 3, r - 3, r - 1, r - 1, col);
        m.pop();
    }

    // ---- esp5: iç içe dönen iki eğik halka
    private static void atom(DrawContext c, MinecraftClient mc, Vec3d center, double w, double time) {
        double r = w * 0.9 + 0.3;
        for (int ring = 0; ring < 2; ring++) {
            double tilt = Math.toRadians(ring == 0 ? 60 : -60);
            double spin = time * (ring == 0 ? 1.5 : -1.5);
            for (int i = 0; i < 40; i++) {
                double a = Math.PI * 2 * i / 40;
                double lx = Math.cos(a) * r, lz = Math.sin(a) * r;
                double y = -lz * Math.sin(tilt), z = lz * Math.cos(tilt);
                double x2 = lx * Math.cos(spin) + z * Math.sin(spin);
                double z2 = -lx * Math.sin(spin) + z * Math.cos(spin);
                double bright = 0.4 + 0.6 * (0.5 + 0.5 * Math.cos(a));
                dot(c, mc, center.add(x2, y, z2), (int) (255 * bright), 2);
            }
        }
    }

    private static void dot(DrawContext c, MinecraftClient mc, Vec3d p, int alpha, int size) {
        double[] s = project(mc, p);
        if (s == null) return;
        int sz = (int) Math.max(1, Math.min(size + 1, Math.round(size * 7.0 / Math.max(s[2], 1.0))));
        int x = (int) s[0] - sz / 2, y = (int) s[1] - sz / 2;
        int a = Math.max(0, Math.min(255, alpha));
        c.fill(x, y, x + sz, y + sz, (a << 24) | 0xFFFFFF);
    }

    /** Dünya -> ekran (ölçekli koordinat). {x, y, derinlik} ya da null. */
    public static double[] project(MinecraftClient mc, Vec3d pos) {
        var cam = mc.gameRenderer.getCamera();
        Vec3d d = pos.subtract(cam.getPos());
        Vec3d fwd = Vec3d.fromPolar(cam.getPitch(), cam.getYaw());
        Vec3d right = fwd.crossProduct(new Vec3d(0, 1, 0));
        if (right.lengthSquared() < 1.0E-6) return null;
        right = right.normalize();
        Vec3d up = right.crossProduct(fwd);

        double f = d.dotProduct(fwd);
        if (f < 0.1) return null;
        double sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        double tan = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        double sx = sw / 2.0 + (d.dotProduct(right) / (f * tan * (sw / sh))) * (sw / 2.0);
        double sy = sh / 2.0 - (d.dotProduct(up) / (f * tan)) * (sh / 2.0);
        return new double[]{sx, sy, f};
    }
}
